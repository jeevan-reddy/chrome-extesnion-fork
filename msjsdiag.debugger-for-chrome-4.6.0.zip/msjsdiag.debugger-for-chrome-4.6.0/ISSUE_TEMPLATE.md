<!-- Please see the debugging tips in the README.md before filing an issue. Especially the tip about using the `.scripts` command for debugging sourcemap issues. -->

- VS Code Version:
- Log file (set `"trace": true` in launch config):

Steps to reproduce:

1.
2.